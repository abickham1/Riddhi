@FunctionalInterface
public interface FilterFunction {
    public boolean test(Hotel hotel);
}
